import java.io.BufferedReader;
import java.io.File;
//import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class AdvanceJavaAssignment {
	public static Connection con;
	public static ResultSet rs;
	public static void connect() throws Exception {
		try{  
//			URL: sql12.freemysqlhosting.net
//			Database: sql12274592
//			Username: sql12274592
//			Password: BYKrdA3mDn
			
        	String dbDriver = "com.mysql.cj.jdbc.Driver"; 
            String dbURL = "jdbc:mysql://sql12.freemysqlhosting.net/"; 
            String dbName = "sql12274592"; 
            String dbUsername = "sql12274592"; 
            String dbPassword = "BYKrdA3mDn"; 
          
            Class.forName(dbDriver); 
            con = DriverManager.getConnection(dbURL + dbName,dbUsername,dbPassword);   
             //con.close();
        }
        catch(Exception e){ 
        	System.out.println(e);
           }  
//		Class.forName("com.mysql.cj.jdbc.Driver");
//		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mymavendatabase","root","root");
	}
	
	public static void databaseToXml(String fileName)throws Exception{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder builder = factory.newDocumentBuilder();
	    Document doc = builder.newDocument();
	    Element results = doc.createElement("Results");
	    doc.appendChild(results);
	    
	    connect();
	    
	    rs = con.createStatement().executeQuery("select * from emp");

	    ResultSetMetaData rsmd = rs.getMetaData();
	    int colCount = rsmd.getColumnCount();

	    while (rs.next()) {
	      Element row = doc.createElement("Row");
	      results.appendChild(row);
	      for (int i = 1; i <= colCount; i++) {
	        String columnName = rsmd.getColumnName(i);
	        Element node = doc.createElement(columnName);
	        node.appendChild(doc.createTextNode(""+rs.getString(i)));
	        row.appendChild(node);
	      }
	    }
	    DOMSource domSource = new DOMSource(doc);
	    TransformerFactory tf = TransformerFactory.newInstance();
	    Transformer transformer = tf.newTransformer();
	    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	    transformer.setOutputProperty(OutputKeys.METHOD, "xml");
	    transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");

	    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	    StreamResult sr = new StreamResult(new File(fileName));
	    transformer.transform(domSource, sr);

	}
	
  public static void main(String args[]) throws Exception {
    databaseToXml("SonaliXml.xml");
    insert("3009","Sonali","Intern","456","2012-08-12","6557","875","20");
    databaseToXml("SonaliXml2.xml");
    compareXmlFiles("SonaliXml.xml","SonaliXml2.xml");
    con.close();
    rs.close();
  }
  
  public static void insert(String empno,String ename,String job,String mgr,String hiredate,String sal,String comm,String deptno) throws SQLException {
	  String row = " insert into emp value"
	  		+ "("+empno+",'"+ename+"','"+job+"',"+mgr+ ",'"+hiredate+"',"+sal+","+comm+","+deptno +")";
	  Statement stmt = con.prepareStatement(row);
		stmt.executeUpdate(row);
  }
  
 
@SuppressWarnings("resource")
public static void compareXmlFiles(String fileName1,String fileName2) throws IOException {
		int count=0;
	  	File file1 = new File(fileName1);
		File file2=new File(fileName2);
		BufferedReader FirstXML = new BufferedReader(new FileReader(file1));
		BufferedReader secondXML = new BufferedReader(new FileReader(file2));
		String line1 = FirstXML.readLine();
		String line2 = secondXML.readLine();
	    
		while(line1 != null && line2!=null)
		{
			count++;
			if(line1.equals(line2))
			{
				System.out.println("line"+count+":  Matching");
				//System.out.println("line1 "+line1);
				//System.out.println("line2 "+line2);
				line1=FirstXML.readLine();
				line2=secondXML.readLine();
			}
			else
			{
				System.out.println("line"+count+":  Not Matching");
				//System.out.println("line1 "+line1);
				//System.out.println("line2 "+line2);
				System.out.println("Not matching records are :"+ line2);
				line2=secondXML.readLine();
			}
		}
  }
  
}


